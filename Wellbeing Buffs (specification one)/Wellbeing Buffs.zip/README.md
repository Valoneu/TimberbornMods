# Description
- changes the % of wellbeing tiers

# Changelog

1.0.4 Fixed release

