# WellBeing Buffs

- changes the % of wellbeing tiers
