# Description
- changes the % of wellbeing tiers

# Changelog
1.0.5 Fix for new update

1.0.4 Fixed release

